const mongoose = require("mongoose");

const addressSchema = new mongoose.Schema({
  name: { type: String },
  phone: { type: Number },
  pincode: { type: Number },
  state: { type: String },
  city: { type: String },
  locality: { type: String },
  landmark: { type: String },
});

const buyingSchema = new mongoose.Schema({
  email: { type: String, required: true},
  username:{type:String},
  addresses: [addressSchema],
  orders:[String],
});

module.exports = mongoose.model("BuyingModule", buyingSchema);
